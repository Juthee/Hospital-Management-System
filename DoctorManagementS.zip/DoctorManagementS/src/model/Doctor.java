package model;

import com.google.gson.*;
import java.sql.*;

public class Doctor 
{ 	
	private Connection connect()
	 {
	 Connection con = null;
	 try
	 {
	 Class.forName("com.mysql.jdbc.Driver");

	 //Provide the correct details: DBServer/DBName, username, password
	 con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/doctordb", "root", "");
	 }
	 catch (Exception e)
	 {e.printStackTrace();}
	
	 return con;
	 }	
	
	
	public String insertDoctor(String firstName, String lastName, String gender, String email,String phone, String specialization,String address)
	{
		String output = "";
		try
		{
		
			Connection con = connect();
			
				if (con == null)
				{return "Error while connecting to the database for inserting."; }
				// create a prepared statement
				String query = " insert into doctor(`doctorID`,`doctorfirstName`,`doctorlastName`,`doctorGender,`doctorEmail`,`doctorPhone,`doctorSpecialization`,`address`)"
						+ " values (?, ?, ?, ?, ?, ?, ?, ?)";
				
				PreparedStatement preparedStmt = con.prepareStatement(query);
				
				// binding values
				preparedStmt.setInt(1, 0);
				preparedStmt.setString(2, firstName);
				preparedStmt.setString(3, lastName);
				preparedStmt.setString(4, gender);
				preparedStmt.setString(5, email);
				preparedStmt.setString(6, phone);
				preparedStmt.setString(7, specialization);
				preparedStmt.setString(8, address);

				// execute the statement
				preparedStmt.execute();
				con.close();
				
				output = "Inserted successfully";
			}
			catch (Exception e)
			{
				output = "Error while inserting the doctor details.";
				System.err.println(e.getMessage());
			}
			
			return output;
		}
		
		public String readDoctor()
		{
			String output = "";
				
			try
			{
				
				Connection con = connect();
				if (con == null)
				{return "Error while connecting to the database for reading."; }
				
				// Prepare the html table to be displayed
				output = "<table border=\"1\"><tr><th>Doctor firstName</th><th>Doctor lastName</th><th>Doctor Gender</th><th>Doctor Email</th><th>Doctor Phone</th><th>Doctor Specialization</th><th>Address</th><th>Update</th><th>Remove</th></tr>";
				
				String query = "select * from doctor";
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				
				// iterate through the rows in the result set
				while (rs.next())
				{
					String doctorID = Integer.toString(rs.getInt("doctorID"));
					String doctorfirstName = rs.getString("doctorfirstName");
					String doctorlastName = rs.getString("doctorlastName");
					String doctorGender = rs.getString("doctorGender");
					String doctorEmail =rs.getString("doctorEmail");
					String doctorPhone =rs.getString("doctorPhone");
					String doctorSpecialization = rs.getString("doctorSpecialization");
					String address = rs.getString("address");
				
					// Add into the html table
					output += "<tr><td>" + doctorfirstName + "</td>";
					output += "<td>" + doctorlastName + "</td>";
					output += "<td>" + doctorGender + "</td>";
					output += "<td>" + doctorEmail + "</td>";
					output += "<td>" + doctorPhone + "</td>";
					output += "<td>" + doctorSpecialization + "</td>";
					output += "<td>" + address + "</td>";
				
					// buttons
					output += "<td><input name=\"btnUpdate\" type=\"button\"value=\"Update\" class=\"btn btn-secondary\"></td>"
									+ "<td><form method=\"post\" action=\"doctor.jsp\">"+ "<input name=\"btnRemove\" type=\"submit\" value=\"Remove\"class=\"btn btn-danger\">"
											+ "<input name=\"doctorID\" type=\"hidden\" value=\"" + doctorID
											+ "\">" + "</form></td></tr>";
				}
				
				con.close();
				
				// Complete the html table
				output += "</table>";
			}
			catch (Exception e)
			{
				output = "Error while reading the doctor details.";
				System.err.println(e.getMessage());
			}
			return output;
		}
		
		public String updateDoctor(String ID, String firstName, String lastName,String gender,String email, String phone, String specialization , String address)
		{
		String output = "";
		
		try
		{
			Connection con =connect();
				
				if (con == null)
				{return "Error while connecting to the database for updating."; }
		
				// create a prepared statement
				String query = "UPDATE doctor SET doctorfirstName=?,doctorlastName=?,doctorgender=?,doctorEmail=?,doctorPhone=?,doctorSpecialization=?,address=? WHERE doctorID=?";
								
				PreparedStatement preparedStmt = con.prepareStatement(query);
		
				// binding values
				preparedStmt.setString(1, firstName);
				preparedStmt.setString(2, lastName);
				preparedStmt.setString(3, gender);
				preparedStmt.setString(4, email);
				preparedStmt.setString(5, phone);
				preparedStmt.setString(6, specialization);
				preparedStmt.setString(7, address);
				preparedStmt.setInt(8, Integer.parseInt(ID));
		
				// execute the statement
				preparedStmt.execute();
				con.close();
		
				output = "Updated successfully";
		}
		catch (Exception e)
		{
			output = "Error while updating the doctor details.";
			System.err.println(e.getMessage());
		}
			return output;
	}
	
	public String deleteDoctor(String doctorID)
	{
		String output = "";
		
		try
		{
			Connection con = connect();
			
			if (con == null)
			{return "Error while connecting to the database for deleting."; }
		
			// create a prepared statement
			String query = "delete from doctor where doctorID=?";
		
			PreparedStatement preparedStmt = con.prepareStatement(query);
		
			// binding values
			preparedStmt.setInt(1, Integer.parseInt(doctorID));
		
			// execute the statement
			preparedStmt.execute();
			con.close();
		
			output = "Deleted successfully";
		}
		catch (Exception e)
		{
			output = "Error while deleting the doctor details.";
			System.err.println(e.getMessage());
		}
		
		return output;
		}
}
