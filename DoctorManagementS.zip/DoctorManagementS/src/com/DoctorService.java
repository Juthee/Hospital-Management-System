package com;

import model.Doctor;

//For REST Service
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

//For JSON
import com.google.gson.*;

//For XML 
import org.jsoup.*;
import org.jsoup.parser.*;
import org.jsoup.nodes.Document;

//For REST Service
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
//For JSON
import com.google.gson.*;
//For XML
import org.jsoup.*;
import org.jsoup.parser.*;
import org.jsoup.nodes.Document;
@Path("/Doctor")

public class DoctorService {
	Doctor doctorObj = new Doctor();
	@GET
	@Path("/")
	@Produces(MediaType.TEXT_HTML)
	public String readDoctor()
	{
	return doctorObj.readDoctor();
	}
	
	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String insertDoctor(@FormParam("doctorID") int doctorID,@FormParam("doctorfirstName") String doctorfirstName,@FormParam("doctorlastName") String doctorlastName,@FormParam("doctorGender") String doctorGender,@FormParam("doctorEmail") String doctorEmail,@FormParam("doctorPhone") String doctorPhone,@FormParam("doctorSpecialization") String doctorSpecialization,@FormParam("address") String address)
	{
		String output = doctorObj.insertDoctor(doctorfirstName, doctorlastName, doctorGender, doctorEmail, doctorPhone, doctorSpecialization, address);
		return output;
	}
	
	@PUT
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String updateDoctor(String doctorData)
	{
	//Convert the input string to a JSON object
	JsonObject doctorObject = new JsonParser().parse(doctorData).getAsJsonObject();
	//Read the values from the JSON object
	String doctorID = doctorObject.get("doctorID").getAsString();
	String doctorfirstName = doctorObject.get("doctorfirstName").getAsString();
	String doctorlastName = doctorObject.get("doctorlastName").getAsString();
	String doctorGender = doctorObject.get("doctorGender").getAsString();
	String doctorEmail = doctorObject.get("doctorEmail").getAsString();
	String doctorPhone = doctorObject.get("doctorPhone").getAsString();
	String doctorSpecialization = doctorObject.get("doctorSpecialization").getAsString();
	String address = doctorObject.get("address").getAsString();
	String output = doctorObj.updateDoctor(doctorID, doctorfirstName, doctorlastName,doctorGender, doctorEmail,doctorPhone, doctorSpecialization,address);
	return output;
	}
	
	@DELETE
	@Path("/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public String deleteDoctor(String doctorData)
	{
	//Convert the input string to an XML document
	Document doc = Jsoup.parse(doctorData, "", Parser.xmlParser());
	//Read the value from the element <doctorID>
	String doctorID = doc.select("doctorID").text();
	String output = doctorObj.deleteDoctor(doctorID);
	return output;
	}
}
